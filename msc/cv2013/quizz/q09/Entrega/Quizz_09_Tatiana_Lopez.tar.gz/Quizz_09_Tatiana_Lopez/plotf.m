function plotf(x,y,ym,yr,yout)
    plot(x,y,'g+'); hold on
    plot(x,yr,'b'); hold on
    plot(x,ym,'r'); hold on
    plot(x,yout,'y'); hold on
end