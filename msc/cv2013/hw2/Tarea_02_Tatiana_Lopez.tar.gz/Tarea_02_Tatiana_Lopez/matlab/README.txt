El archivo que ejecuta la primera parte de la tarea (remover distorción proyectiva)
se llama hw2ToAffinity.m

El archivo que ejecuta la primera parte de la tarea (remover distorción proyectiva)
se llama hw2ToSimilarity.m
