########### COMPILE
make

########### RUN
# Ussage : img1, img2, stdev, harrisK, harrisW, harrisThrs, ssdThrs, nccThrs, corrW, corrKnownMovement

#Test 1:
./POIMatching img/benevolentAnnika.jpg img/benevolentAnnikaRot.jpg 0.09f 0.4f 0.4f 0.97f

#Test 2:
./POIMatching img/puregeometryRomanowsky.png img/puregeometryRomanowskyPersp.png 0.04f 0.25f 1.2f 0.92f

#Test 3:
./POIMatching img/foto1.jpg img/foto2.jpg 0.09f 0.45f 0.8f 0.95f
